import requests
import json
from os.path import dirname, join
import sys
import pandas as pd
import logging
import pyodbc
from azure.data.tables import TableClient
from Report import Report
import openpyxl
from FunctionLibrary.Generic.GenericFunction import *

from collections import defaultdict

global cred
global result
global reqData
global dbRows
global lenDBRows

logging.basicConfig(filename="./Logs/events.log", format='%(asctime)s - %(name)s - %(levelname)s  - %(message)s',
                    filemode='w', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

requestName = set()
requestCountries = {}

with open('Configuration/config.json', 'r') as f:
    config = json.load(f)

# with open('./InterfaceUrl/' + cred['Environment'] + '-urlList.json', 'r') as f:
#    urlList = json.load(f)


def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = dirname(__file__)
    return join(base_path, relative_path)


def flatten_list(lst):
    di = defaultdict(list)
    if type(lst[0]) is dict:
        for i in lst:
            for j in range(len(list(i.items()))):
                k, v = list(i.items())[j]
                di[k].append(v)
        for x in di:
            res = any(isinstance(sub, list) for sub in di[x])
            if not res and type(di[x]) is list:
                new_list = list(set(di[x]))
                di[x] = new_list
        return dict(di)
    else:
        return lst


def flatten_dict(dd, separator='_', prefix=''):
    return {prefix + separator + k if prefix else k: v
        for kk, vv in dd.items()
        for k, v in flatten_dict(vv, separator, kk).items()
        } if isinstance(dd, dict) else {prefix: dd}

def get_request(details,script):
    requestURL = details["request"]["url"]
    requestHeaders = details['request']['headers']
    print('Triggered API request...')
    res = requests.get(requestURL,headers=requestHeaders, proxies=config['proxies'])
    report.resJson(res, script)

    # Write Actual Response to folder - ActualReponses
    actual_response = open("./ActualResponses/" + script + ".json", "w")
    actual_response.write(json.dumps(res.json(), indent=4))
    if details["scenario"] == "GETsuggestedPrice":
        response_path = "./ActualResponses/"+script+".json"
        apply_price_response = "./ExpectedResponses/qvp_applyPrice_POST.json"
        apply_price_request = "./Requests/qvp_applyPrice_POST.json"
        modifyApplyPriceRequest(response_path,apply_price_request)
        modifyApplyPriceResponse(response_path,apply_price_response)

def put_request(details,script):
    requestURL = details["request"]["url"]
    requestData = details['request']['data']
    requestHeaders = details['request']['headers']

    print('Triggered API request...')
    res = requests.put(requestURL, json=requestData, headers=requestHeaders, proxies=config['proxies'])
    report.resJson(res, script)

def delete_request(details,script):
    requestURL = details["request"]["url"]
    requestData = details['request']['data']
    requestHeaders = details['request']['headers']

    print('Triggered API request...')
    res = requests.delete(requestURL, json=requestData, headers=requestHeaders, proxies=config['proxies'])
    report.resJson(res, script)

def post_request(details, script):

    requestURL = details["request"]["url"]
    # site_table = details["site_id_table"]
    requestData = details['request']['data']
    requestHeaders = details['request']['headers']
    # table_and_query = details["sqlTablesAndQueries"]

    # Scenario
    if details["scenario"] == "ApplyPrice":
        #Modify Site ID and replace in the endpoint uRL
        # details['request']['url'] = update_endpoint(data,tempRequestURL)
        # requestUrl = details['request']['url']
        pass

        #Update new site ID in the DB query
        # new_query = updatedSiteIDQuery(data[0]["SITE_ID"],table_and_query["reporting_ITC"])
        # table_and_query["reporting_ITC"] = new_query
    res = requests.post(requestURL, json=requestData, headers=requestHeaders, proxies=config['proxies'])

    print('Triggered API request...')
    report.resJson(res,script)

    #Write Actual Response to folder - ActualReponses
    actual_response = open("./ActualResponses/"+ script + ".json", "w")
    actual_response.write(json.dumps(res.json(), indent=4))

def validateSchema(script):
    with open('./ActualResponses/'+script+'.json') as f:
        response = json.load(f)
        generateJsonSchema(script)
        validateAPISchema(response,script+'.json')

def responseValidation(details,script):
    actual_expected_response_validation(details,script)
        
def validate_db(details, script):
    dbType = details["dbType"]
    azure_query = details["azureQuery"]
    for db in dbType:
        if db == "ATS":
            for ats_table,query in details["azureTablesAndQueries"].items():
                data = AzureTableQuery(config["ATSConnectionString"], ats_table, query)
                print("ATS DATA",data)
                mapKeys = getDBFieldsFromMapping(details, db)
                response_file = "./ActualResponses/" + script + ".json"
                applyPriceValidationATS(response_file, data, mapKeys)

        elif db == "SQL":
            for sql_table,query in details["sqlTablesAndQueries"].items():
                cursor = connectToSQL(config["DSNITC"],config["usernameSQL"],config["passwordSQL"],
                             config[sql_table])
                mapKeys = getDBFieldsFromMapping(details,db)
                values = mapKeys.values()
                updated_query = modifyQuery(query,values)
                data = execute_SQL_Query(updated_query,cursor)
                response_file = "./ActualResponses/"+ script + ".json"
                applyPriceValidationSQL(response_file,data,mapKeys)




try:

    data = pd.read_csv("./Execution Manager/ExecutionManager.csv")
    yesIndexes = list(data.groupby("Execute").indices['Yes'])
    Scripts = list(data.iloc[yesIndexes]["RequestName"])

    apiDf = pd.DataFrame(columns=['InterfaceName', 'URL', 'StatusCode', 'Result'])
    iname = []
    urls = []
    apiStatus = []
    apiRes = []
    Result = {}
    for i in yesIndexes:
        try:
            print('                               ')
            print('                               ')
            print('Executing test case', i+1, '...')

            validation = data.iloc[i].Validation
            script = data.iloc[i].RequestName
            report = Report()
            report.initScriptReport(script)
            if "GET" not in script and "POST" not in script:
                report.appendStep("Script Name Validation", "The script name is incorrect",
                                  "The script name should end with 'GET' or 'POST'",
                                  "The script name doesnt have 'GET' or 'POST'")
                Result[script] = report.deinitScriptReport(script)


            else:
                with open('./Requests/'+ script + ".json", 'r') as f:
                    details = json.load(f)

                if not validation in ["API-DB","API"]:
                    report.appendStep("Execution Manager configuration","The details specified in "
                                                                        "Execution Manager is incorrect",
                                      "Validation should be either 'API' or 'API-DB'","Incorrect value given for Validation")
                    Result[script] = report.deinitScriptReport(script)
                elif validation == "API-DB":
                    if "GET" in script:
                        # call GET method
                        get_request(details,script=script)
                        validateSchema(script)
                        responseValidation(details, script)
                        Result[script] = report.deinitScriptReport(script)
                    elif "POST" in script:
                        post_request(details, script=script)
                        validateSchema(script)
                        responseValidation(details,script)
                        validate_db(details,script=script)
                        Result[script] = report.deinitScriptReport(script)
                elif validation == "API":
                    if "GET" in script:
                        # call GET method
                        get_request(details, script=script)
                        validateSchema(script)
                        responseValidation(details, script)
                        Result[script] = report.deinitScriptReport(script)
                    elif "POST" in script:
                        post_request(details, script=script)
                        validateSchema(script)
                        responseValidation(details, script)
                        Result[script] = report.deinitScriptReport(script)


        except Exception as e:
            print(e)
            logger.exception("Exception Occured")
            Result[script] = report.deinitScriptReport(script)


    print('                               ')
    print('                               ')
    print('Loading results...')
    report.deinitReport(Scripts, Result)

except Exception as e:
    print(e)
    logger.exception("Exception Occured")
    Result[script] = report.deinitScriptReport(script)
    report.deinitReport(Scripts, Result)
