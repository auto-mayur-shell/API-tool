import jsonschema
import pyodbc
import openpyxl
import json
import json_tools as jt
from azure.data.tables import TableClient
from deepdiff import DeepDiff
from jsonschema import validate
from Report import Report
from datetime import datetime
import datetime as dt
from genson import SchemaBuilder



report = Report()


def connectToAzureTable(connString, tableName):
    table_client = TableClient.from_connection_string(conn_str=connString, table_name=tableName)
    return table_client


def connectToSQL(DSNName, UID, PWD, tableName):
    try:
        Connection = pyodbc.connect(
            "DSN=" + DSNName + ';' "UID=" + UID + ';' "PWD=" + PWD + ';' "database=" + tableName)
        if Connection is not None:
            Cursor = Connection.cursor()
            Connection.autocommit = True
            return Cursor
    except Exception as e:
        print("SQL", e)


def execute_SQL_Query(query, Cursor):
    row = Cursor.execute(query)
    if row.description is None:
        Data = None
        print("update Query Successfully Updated")
    else:
        Data = [dict(zip([key[0] for key in Cursor.description], result))
                for result in row.fetchall()]
    return Data


def convertListToString(sampledict):
    result = '[%s]' % ', '.join(map(str, sampledict))
    result = str(result)[1:-1]
    return result


def modifyQuery(query, dict):
    parts = query.split("*")
    updated_Fields = convertListToString(dict)
    updated_query = parts[0] + updated_Fields + parts[1]
    return updated_query

def updatedSiteIDQuery(siteID,query):
    l = query.split(" ")
    temp = l[7].split("=")
    temp[1] = "'" + str(siteID) + "'"
    new_temp = "=".join(temp)
    l[7] = "".join(new_temp)
    new_query = " ".join(l)
    return new_query


def getDBFieldsFromMapping(testData, dbType):
    if "mapping" in testData:
        mappingDetails = testData['mapping']
        path = mappingDetails["Path"]
        SheetName = mappingDetails["SheetName"]
        APIColumn = mappingDetails["APIColumn"]
        if dbType == "ATS":
            DBColumn = "B"
        elif dbType == "SQL":
            DBColumn = "C"
        mapKeys = {}
        xl = openpyxl.open(path)
        sheet = xl[SheetName]

        for i in range(1, len(sheet[APIColumn])):
            if dbType == "ATS":
                if sheet[APIColumn][i].value in testData["ATSFields"]:
                    mapKeys[sheet[APIColumn][i].value] = sheet[DBColumn][i].value
            if dbType == "SQL":
                if sheet[APIColumn][i].value in testData["SQLFields"]:
                    mapKeys[sheet[APIColumn][i].value] = sheet[DBColumn][i].value

    else:
        mapKeys = None

    return mapKeys

def formatDateInAPI(date):
    parts = date.split("+")
    return parts[0]

def convertToValidDate(dbDate):
    new_date = (dbDate + dt.timedelta(hours=1)).strftime('%Y-%m-%dT%H:%M:%S')
    return new_date

def applyPriceValidationSQL(responseFile, sqlData, mapKeys):
    f = open(responseFile, "r")
    response = json.load(f)
    # Fetch API Date:
    api_date = formatDateInAPI(response["localValidFromTime"])
    # Validate Site ID
    for j in range(len(sqlData)):
        # Site ID Validation
        if response["siteId"] == str(sqlData[j][mapKeys["siteId"]]):
            report.appendStep("SITE ID Validation for SQL DB row " + str(j + 1),
                              "Verify if Site ID in API response & DB are matching",
                              response["siteId"], str(sqlData[j][mapKeys["siteId"]]))
        else:
            report.appendStep("SITE ID Validation for SQL DB row " + str(j + 1),
                              "Verify if Site ID in API response & DB are matching",
                              response["siteId"], str(sqlData[j][mapKeys["siteId"]]))

    # Validate validFromDate
    for j in range(len(sqlData)):
        # validFromDate validation
        db_date = convertToValidDate(sqlData[j][mapKeys["localValidFromTime"]])
        if api_date == db_date:
            report.appendStep("Valid From Date Validation for SQL DB row " + str(j + 1),
                              "Verify if Valid From Date in API response & DB are matching",
                              api_date, db_date)
        else:
            report.appendStep("Valid From Date Validation for SQL DB row " + str(j + 1),
                              "Verify if Valid From Date in API response & DB are matching",
                              api_date, db_date)
    # Validation of Product ID & Price
    i = 0
    while i < len(response["productPrices"]):
        for product in response["productPrices"]:
            found = False
            for j in range(len(sqlData)):
                if product["productId"] == str(sqlData[j][mapKeys["productId"]]):
                    found = True
                    report.appendStep("Product ID Validation for SQL DB",
                                      "Verify if Product ID in API response & DB are matching",
                                      product["productId"], str(sqlData[j][mapKeys["productId"]]))
                    if product["price"] == float(sqlData[j][mapKeys["price"]]):
                        report.appendStep("Price Validation for SQL DB",
                                          "Verify if Price in API response & DB are matching",
                                          str(product["price"]), str(sqlData[j][mapKeys["price"]]))
                    else:
                        report.appendStep("Price Validation for SQL DB",
                                          "Verify if Price in API response & DB are matching",
                                          str(product["price"]), str(sqlData[j][mapKeys["price"]]))
                if found:
                    break
            else:
                report.appendStep("Product ID & Price Validation for SQL DB",
                                  "Verify if Price & product ID in API response & DB are matching",
                                  "product ID "+product["productId"]+" and Price "+str(product["price"])+
                                  " are available in DB", "product ID "
                                                          +product["productId"]+" and Price "
                                                          +str(product["price"]+" are not available in DB"))
            i+=1


def applyPriceValidationATS(responseFile,atsData,mapKeys):
    f = open(responseFile, "r")
    response = json.load(f)
    refPrices = json.loads(atsData[0]["ReferencePrices"])
    # Validated Reference Prices for a Product
    for product in response["productPrices"]:
        for refPrice in refPrices:
            foundProduct = False
            if product["productId"] == str(refPrice[mapKeys["productId"]]):
                foundProduct = True
                report.appendStep("Product ID Validation for ATS DB",
                                  "Verify if Product ID in API response & DB are matching",
                                  product["productId"], str(refPrice[mapKeys["productId"]]))
                #Validate ReferencePrices
                for refParamDB, refParamResp in zip(refPrice["ReferencePrices"],product["referenceParameterPrices"]):
                    #Reference Parameter ID Validation
                    if refParamResp["id"] == str(refParamDB[mapKeys["id"]]):
                        report.appendStep("Reference Parameter ID Validation for ATS DB",
                                          "Verify if Reference Parameter ID in API response & DB are matching",
                                          refParamResp["id"], str(refParamDB[mapKeys["id"]]))
                        # Reference Parameter Code Validation
                        if refParamResp["code"] == str(refParamDB[mapKeys["code"]]):
                            report.appendStep("Reference Parameter code Validation for ATS DB",
                                              "Verify if Reference Parameter code in API response & DB are matching",
                                              refParamResp["code"], str(refParamDB[mapKeys["code"]]))
                        else:
                            report.appendStep("Reference Parameter code Validation for ATS DB",
                                              "Verify if Reference Parameter code in API response & DB are matching",
                                              refParamResp["code"], str(refParamDB[mapKeys["code"]]))
                        # Reference Parameter Value Validation
                        if refParamResp[0]["value"] == str(refParamDB[mapKeys["value"]]):
                            report.appendStep("Reference Parameter value Validation for ATS DB",
                                              "Verify if Reference Parameter value in API response & DB are matching",
                                              refParamResp["value"], str(refParamDB[mapKeys["value"]]))
                        else:
                            report.appendStep("Reference Parameter value Validation for ATS DB",
                                              "Verify if Reference Parameter value in API response & DB are matching",
                                              refParamResp["value"], str(refParamDB[mapKeys["value"]]))
                    else:
                        report.appendStep("Reference Parameter ID Validation for ATS DB",
                                          "Verify if Reference Parameter ID in API response & DB are matching",
                                          refParamResp["id"], str(refParamDB[mapKeys["id"]]))
            if foundProduct:
                break

def generateJsonSchema(Script):
    with open('./ExpectedResponses/'+Script+'.json') as f:
        response = json.load(f)
    builder = SchemaBuilder()
    builder.add_object(response)
    print(builder.to_schema())
    schema = builder.to_schema()
    with open('./Schemas/' + Script+'.json', 'w') as schema_file:
        json.dump(schema, schema_file)


def validateAPISchema(Response, SchemaFileName):
    with open('./Schemas/' + SchemaFileName) as f:
        SchemaJson = json.load(f)
    try:
        validate(instance=Response, schema=SchemaJson)
        report.appendStep("Schema Validation",
                          "Verify if the API response is as per schema",
                          "API is as per schema", "API is as per schema")
    except jsonschema.exceptions.ValidationError as err:
        report.appendStep("Schema Validation",
                          "Verify if the API response is as per schema",
                          "Schema Validation Failed", str(err))

def update_endpoint(siteIdVal, tempURL):
    temp= tempURL.split("/")
    site_id = str(siteIdVal[0])
    temp[5] = site_id
    new_url = '/'.join(temp)
    return new_url


def actual_expected_response_validation(details, script):
    uncompared_values = []
    try:
        with open('./ActualResponses' + '/' + script + '.json') as f1, open(
                './ExpectedResponses' + '/' + script + '.json') as f2:
            act_res = json.load(f1)
            exp_res = json.load(f2)
            try:
                ignored_values = sorted(details['ignored_Fields'])
            except:
                report.appendStep(
                    "Fetching ignored_Fields attribute", f"ignored_Fields attribute is a list"
                                                         f" containing values that need to be "
                                                         f"excluded during actual and expected value "
                                                         f"comparison", f"Expected ignored_Fields "
                                                                        f"attribute",
                    f"ignored_Fields attribute not found")
        if isinstance(act_res, list):
            act_res = act_res[0]
        if isinstance(exp_res, list):
            exp_res = exp_res[0]
        for val in ignored_values:
            uncompared_values.extend(ignored_key_remover(act_res, val))
        for val in ignored_values:
            uncompared_values.extend(ignored_key_remover(exp_res, val))
        result = jt.diff(act_res, exp_res)
        if len(result) > 0:
            # differences are there
            for item in result:
                for key, value in item.items():
                    if key == "add":
                        report.appendStep(
                            "Actual vs Expected responses comparison",
                            f"The field {item['add']} is found only in Expected Response. <a href='../../.././ExpectedResponses/qvp_applyPrice_POST.json'>Expected Response</a>",
                            item["add"], None)
                    elif key == "replace":
                        report.appendStep(
                            "Actual vs Expected responses comparison",
                            f"The field {item['replace']} has mismatch among responses", item[
                                                                                             "value"] + " " + "<a href='../../.././ExpectedResponses/qvp_applyPrice_POST.json'>Expected Response</a>",
                                                                                         item[
                                                                                             "prev"] + " " + "<a href='../../.././ActualResponses/qvp_applyPrice_POST.json'>Actual Response</a>")
                    elif key == "remove":
                        report.appendStep(
                            "Actual vs Expected responses comparison",
                            f"The field {item['remove']} is found only in Actual Response <a href='../../.././ActualResponses/qvp_applyPrice_POST.json'>Actual Response</a>",
                            None, item["remove"])
        else:
            report.appendStep(
                "Actual vs Expected responses comparison",
                "Comparing two files - Actual & Expected Responses for differences <a href='../../.././ActualResponses/qvp_applyPrice_POST.json'>Actual Response</a> <a href='../../.././ExpectedResponses/qvp_applyPrice_POST.json'>Expected Response</a>",
                "No differences found",
                "No differences found")

    except Exception as e:
        print(e)

def ignored_key_remover(d, key, removed_keys = []):
    if isinstance(d, list):
        for i in d:
            ignored_key_remover(i, key, removed_keys)
    elif isinstance(d, dict):
        if key in d:
            removed_keys.append(key)
            del d[key]
        for i in d.values():
            ignored_key_remover(i, key, removed_keys)
    return removed_keys


def AzureTableQuery(ConnectionString, tableName, Query):
    table_client = TableClient.from_connection_string(conn_str=ConnectionString, table_name=tableName)
    data = table_client.query_entities(Query)
    # report.appendStep(scriptName, "ATS Connection", "Fetching data  from ATS","","")
    finalData = []
    for j in data:
        dic = {}
        for o in j.keys():
            dic[o] = j[o]
        finalData.append(dic)
    return finalData

def modifyApplyPriceRequest(suggestedPriceResponse,applyPriceRequest):
    with open(suggestedPriceResponse, 'r') as jf:
        jsonFile = json.load(jf)
        data = jsonFile[0]
    tempDict = {}
    tempList = []
    siteId = []
    ignore_keys = ('siteId', 'siteCode', 'siteLock')
    ignore_values = (
    'code', 'sortOrder', 'isRuleOutput', 'rulesExplanation', 'priceChangeReason', 'brandType', 'productPriceDeltaVal',
    'delayedEventsInfo', 'reactionDelta')
    for key, value in data.items():
        if key == "siteId":
            siteId.append(data[key])
        if key != "productPrices":
            if not key.startswith(ignore_keys):
                tempDict[key] = data[key]
        if key == "productPrices":
            for dic in data[key]:
                temp_dic = {}
                for key1, val1 in dic.items():
                    if not key1.startswith(ignore_values):
                        temp_dic[key1] = dic[key1]
                tempList.append(temp_dic)
    tempDict["productPrices"] = tempList
    with open(applyPriceRequest,"r") as f:
        req = json.load(f)
    req["request"]["data"]["localValidFromTime"] = tempDict["localValidFromTime"]
    req["request"]["data"]["productPrices"] = tempDict["productPrices"]
    req['request']['url'] = update_endpoint(siteId, req['request']['url'])
    apply_price_req = open(applyPriceRequest, "w")
    apply_price_req.write(json.dumps(req, indent=4))


def modifyApplyPriceResponse(suggestedPriceResponse,applyPriceResponse):
    with open(suggestedPriceResponse, 'r') as jf:
        jsonFile = json.load(jf)
        data = jsonFile[0]
    tempDict = {}
    tempList = []
    siteId = []
    siteCode = []
    ignore_keys = ('siteLock')
    ignore_values = (
    'code', 'sortOrder', 'isRuleOutput', 'rulesExplanation', 'priceChangeReason', 'brandType', 'productPriceDeltaVal',
    'delayedEventsInfo', 'reactionDelta')
    for key, value in data.items():
        if key != "productPrices":
            if not key.startswith(ignore_keys):
                tempDict[key] = data[key]
        if key == "productPrices":
            for dic in data[key]:
                temp_dic = {}
                for key1, val1 in dic.items():
                    if not key1.startswith(ignore_values):
                        temp_dic[key1] = dic[key1]
                tempList.append(temp_dic)
    tempDict["productPrices"] = tempList
    with open(applyPriceResponse,"r") as f:
        res = json.load(f)
    res["productPrices"] = tempDict["productPrices"]
    res["siteId"] = tempDict["siteId"]
    res["siteCode"] = tempDict["siteCode"]
    apply_price_res = open(applyPriceResponse, "w")
    apply_price_res.write(json.dumps(res, indent=4))



