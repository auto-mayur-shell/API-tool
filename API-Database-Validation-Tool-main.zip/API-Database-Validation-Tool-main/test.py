import openpyxl


mapKeys = {}
xl = openpyxl.open("./Mapping/Summary Transaction attribute list_Phase-2.xlsx")
sheet = xl["Input"]

for i in range(1, len(sheet["A"])):
    mapKeys[sheet["A"][i].value] = sheet["C"][i].value
print(mapKeys)