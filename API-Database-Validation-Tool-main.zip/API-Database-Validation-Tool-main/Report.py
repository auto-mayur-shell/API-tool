import bs4
import logging
import pandas as pd
from time import strftime
from jinja2 import Environment, FileSystemLoader
import webbrowser
import os
from datetime import date,datetime
import csv,json
import logging




class Report:
    df = ""
    ResultPath=""
    scriptName=""
    handler=""
    logger = logging.getLogger(__name__)
    Step=[]
    Description=[]
    Expected=[]
    Actual=[]
    res=[]
    ss=[]

    def __init__(self):
        self.ResultPath=self.createReportFolder()
        self.handler = logging.FileHandler(self.ResultPath+"/Logs/"+'file.log')
        self.handler.setLevel(logging.ERROR)
        format = logging.Formatter('%(asctime)s => %(levelname)s: ScriptName => %(filename)s/%(module)s/%(funcName)s:%(lineno)d => %(message)s => %(screenshot)s')
        self.handler.setFormatter(format)
        self.logger.addHandler(self.handler)

    def log(self,message,screenshot):
        self.logger.error(message)

    def resJson(self,res,script):
        response_body = open(self.ResultPath+"/res_body_"+script+".json", "w")
        response_body.write(json.dumps(res.json(), indent=4))
        response_body.close()
        self.Step.append("API - POST")
        self.Description.append("API POST call for "+script)
        self.Expected.append("Successful ")
        self.Actual.append("Successful")
        self.res.append("<a href=\".\\res_body_"+script+".json\">Response</a>")

    def dbData(self,data,script):
        db_data = open(self.ResultPath+"/db_data_"+script+".txt", "w")
        for items in data:
            db_data.write('%s\n' % items)
        #db_data.write(data)
        db_data.close()
        self.Step.append("Database")
        self.Description.append("Data")
        self.Expected.append(" ")
        self.Actual.append(" ")
        self.res.append("<a href=\".\\db_data_"+script+".txt\">Database</a>")
    
    def initScriptReport(self,script):
        self.df = pd.DataFrame(columns = ['Step','Description','Expected/DBValue', 'Actual/JSONValue','Result'])
        self.df.columns.name = 'S.No.'
        self.scriptName=script

    def appendStep(self,step,description,expected="",actual=""):
        self.Step.append(step)
        self.Description.append(description)
        self.Expected.append(expected)
        self.Actual.append(actual)
        if actual==expected:
            self.res.append("PASSED")
        # elif isinstance(actual,'str') and actual is not None and expected is not None:
        #    if actual in expected or expected in actual:
        #        self.res.append("PASSED")
        else:
            self.res.append("FAILED")


    def deinitScriptReport(self,script):
        self.df['Step']=self.Step
        self.df['Description']=self.Description
        self.df['Expected/DBValue']=self.Expected
        self.df['Actual/JSONValue']=self.Actual
        self.df['Result']=self.res
        self.Step=[]
        self.Description=[]
        self.Expected=[]
        self.Actual=[]
        self.res=[]
        self.df.to_excel(self.ResultPath+"/result_"+script+".xlsx")
        return self.df



    def deinitReport(self,Scripts,Results):
        self.editReport(Scripts)
        self.ReportGenerator(Results)

    def editReport(self,ScriptNames):

        logger=logging.getLogger("editReport")

        f=open("./Results/report_template.html",'r')
        soup=bs4.BeautifulSoup(f)

        for scriptName in ScriptNames:
            
            new_tag=soup.new_tag('button',attrs={'class':'tablinks','onClick':'openRequest(event,"'+scriptName+'")'})
            new_tag.string=scriptName
            soup.findChild("body").findChild("div",{'class':'tab'}).append(new_tag)

            tabContent=soup.new_tag('div',attrs={'class':'tabcontent','id':scriptName})
            tabContent.string="{{ "+scriptName+" }}"
            
            soup.findChild("body").findChild("script").insert_before(tabContent)
            
        with open("./Results/report.html", "wb") as f_output:
            f_output.write(soup.prettify("utf-8"))

        logger.info("Report.html Generated successfully")

    def ReportGenerator(self,data):
        
        logger=logging.getLogger("ReportGenerator")
        

        def color_positive_green(val):
            if val == 'PASSED':
                color = 'green'
            elif val == 'FAILED':
                color = 'red'
            elif val in ['Response',' ','Body']:
                color = 'lightblue'
            elif val in ['Database',' ','Data']:
                color = 'lightblue'
            else:
                color = 'white'
            return 'background-color: %s' % color
            

        for key in data.keys():
            df=data[key]
            df.index+=1
            data[key]=df.style.set_table_styles({0:[{'selector':'table','props':'width: 1000px;'}]}).applymap(color_positive_green).render()
        
        logger.debug("Pass/Fail Style Applied")

        env = Environment(loader=FileSystemLoader(searchpath=''))
        template = env.get_template('./Results/report.html')
        html=template.render(data)
        r=self.ResultPath+r"\report"+strftime("%Y%m%d-%H%M%S")+".html"
        with open(r,'w') as f:
            f.write(html)
        
        logger.info("Report Generated")
        
        webbrowser.open_new(r)

    def createReportFolder(self):
        logger=logging.getLogger("createReportFolder")

        strDate=str(date.today())
        if not os.path.exists("./Results/"+strDate):
            os.makedirs("./Results/"+strDate)

        strTime=str(datetime.now().time()).replace(":","-")
        if not os.path.exists("./Results/"+strDate+"/"+strTime):
            os.makedirs("./Results/"+strDate+"/"+strTime)
            os.makedirs("./Results/"+strDate+"/"+strTime+"/Logs")
        
        return "./Results/"+strDate+"/"+strTime